#include <iostream>
#include <string>
#include "ui.h"
#include "test.h"
#include <fstream>
using namespace std;

int main()
{
   UI ui;
    ui.start();
    return 0;
}
